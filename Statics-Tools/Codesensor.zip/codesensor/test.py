import copy

import os

def codeSensor():
    os.system("java -jar CodeSensor.jar test.c > output.txt")

codeSensor()
